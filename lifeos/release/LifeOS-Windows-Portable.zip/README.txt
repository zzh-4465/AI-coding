LifeOS Windows Portable

使用方式：

1. 解压整个压缩包。
2. 双击 LifeOS.exe。
3. 如果 Windows 弹出安全提醒，选择“更多信息” -> “仍要运行”。

说明：

- 这是 LifeOS 的 Windows 便携版，不需要安装。
- 建议使用 Windows 10/11。
- 如果无法打开，请先确认系统已安装 Microsoft Edge WebView2 Runtime。Windows 11 通常自带。
- 当前版本是桌面 MVP，支持全屏工作台、Daily Brief、常用工具、本周计划、贴图卡片、临时文件、复盘和今日锁屏图。

注意：

- 当前版本尚未签名，所以朋友电脑可能会出现 Windows 安全提醒。
- 当前不是正式安装包；正式安装包需要 NSIS 打包环境。
